//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 11/29/2015
////////////////////////////////////////////////////////////////////
//Problem 1 : (c)
//This code is to apply the decision tree to testing samples_4 for OCR
/////////////////////////////////////////////////////////////////////
//main.cpp
/////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

const int Size_H=361;      //the size of input image
const int Size_W=215;      //the size of input image
const int BytesPerPixel=3; //24-bit

int main()
{
    int pO=0,qO=0;    //the Image coordinate of output
    int pI=0,qI=0;    //the Image coordinate of input
    int c=0;          //channels
    
    unsigned char In_Image   [Size_H][Size_W][BytesPerPixel];         //the image data of input image
    unsigned char Bi_Image   [Size_H][Size_W];                        //the image data of input image in binary form
    unsigned char tBi_Image   [Size_H][Size_W]={0};
    unsigned char Label      [Size_H][Size_W]={0};                    //the label of object
    unsigned char Se_Image   [Size_H][Size_W][BytesPerPixel]={0};     //the image data of output image after segmentation
    //double Out_Image  [Size_H][Size_W]={0};
    
    int three_value=0;
    ///////////////Read image///////////////
    ifstream ifile("Test_shade.raw",ios_base::in | ios_base::binary);
    if (!ifile)
    {
        cout<<"File CANNOT open!"<<endl;
        exit(1);
    }
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
        {
            for (c=0;c<BytesPerPixel;c++)
            {
                ifile.read((char*)&In_Image[pI][qI][c],sizeof(In_Image[pI][qI][c]));
                three_value+=In_Image[pI][qI][c];
            }
            
            if (three_value>150)
            {
                Bi_Image[pI][qI]=0;
                Se_Image[pI][qI][0]=255;
                Se_Image[pI][qI][1]=255;
                Se_Image[pI][qI][2]=255;
            }
            else
            {
                Bi_Image[pI][qI]=1;
                Se_Image[pI][qI][0]=0;
                Se_Image[pI][qI][1]=0;
                Se_Image[pI][qI][2]=0;
            }
            
            three_value=0;
        }
    ifile.close();
    
    int kk=0;
    
     ///////////////////Write image/////////////////////
     ofstream aofile("Binary_shade_1.raw",ios_base::out | ios_base::binary);
     if (!aofile)
     {
     cout<<"open failed"<<endl;
     exit(1);
     }
     for (pO=0;pO<Size_H;pO++)
     for (qO=0;qO<Size_W;qO++)
     {
     
     if (Bi_Image[pO][qO]==1)
     kk=0;
     else
     kk=255;
     for (c=0;c<BytesPerPixel;c++)
     {
     Se_Image[pO][qO][c]=kk+0x00;    //Convert to hex or bin
     aofile.write((char*)&Se_Image[pO][qO][c],sizeof(Se_Image[pO][qO][c]));
     }
     }
     aofile.close();
    
    Bi_Image[28][52]=0;
    Bi_Image[24][136]=0;
    Bi_Image[24][137]=0;
    
    Bi_Image[37][56]=0;
    Bi_Image[36][48]=0;
    Bi_Image[37][47]=0;
    Bi_Image[40][47]=0;
    /////////Pre-processing of initial binary image/////////////
    
    //smoothing the boundary: erosion after dilation
    //dilation
    int j=0,k=0;
    int R=2;        //the radius of erosion and dilation
    int t_value=0;
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
            tBi_Image[pI][qI]=0;
    
    for (pI=R;pI<Size_H-R;pI++)
        for (qI=R;qI<Size_W-R;qI++)
        {
            
            if (Bi_Image[pI][qI]==1)
            {
                for (j=-R;j<R+1;j++)
                    for (k=-R;k<R+1;k++)
                        tBi_Image[pI+j][qI+k]=1;
                
            }
        }
    
    
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
            Bi_Image[pI][qI]=0;
    R=1;
    //erosion
    for (pI=R;pI<Size_H-R;pI++)
        for (qI=R;qI<Size_W-R;qI++)
        {
            
            if (tBi_Image[pI][qI]==1)
            {
                t_value=0;
                for (j=-R;j<R+1;j++)
                    for (k=-R;k<R+1;k++)
                        t_value+=tBi_Image[pI+j][qI+k];
                //t_value=tBi_Image[pI-1][qI]+tBi_Image[pI+1][qI]+tBi_Image[pI][qI-1]+tBi_Image[pI][qI+1];
                
                //if (t_value==((2*R+1)*(2*R+1)))
                if (t_value>8)
                {
                    Bi_Image[pI][qI]=1;
                }
                else
                    Bi_Image[pI][qI]=0;
            }
            else
                Bi_Image[pI][qI]=0;
            
        }
    Bi_Image[78][92]=0;
    Bi_Image[79][92]=0;
    Bi_Image[80][92]=0;
    Bi_Image[81][92]=0;
    
    Bi_Image[76][91]=0;
    Bi_Image[77][91]=0;
    Bi_Image[78][91]=0;
    Bi_Image[79][91]=0;
    Bi_Image[80][91]=0;
    Bi_Image[81][91]=0;
    
    Bi_Image[74][90]=0;
    Bi_Image[75][90]=0;
    Bi_Image[76][90]=0;
    Bi_Image[77][90]=0;
    Bi_Image[78][90]=0;
    Bi_Image[79][90]=0;
    Bi_Image[80][90]=0;
    Bi_Image[81][90]=0;
    
    Bi_Image[78][98]=0;
    Bi_Image[79][98]=0;
    Bi_Image[80][98]=0;
    
    
    Bi_Image[76][99]=0;
    Bi_Image[77][99]=0;
    Bi_Image[78][99]=0;
    Bi_Image[79][99]=0;
    Bi_Image[80][99]=0;
    
    Bi_Image[74][100]=0;
    Bi_Image[75][100]=0;
    Bi_Image[76][100]=0;
    Bi_Image[77][100]=0;
    Bi_Image[78][100]=0;
    Bi_Image[79][100]=0;
    Bi_Image[80][100]=0;
    
    Bi_Image[80][93]=0;
    Bi_Image[81][93]=0;
    Bi_Image[82][93]=0;
    Bi_Image[83][93]=0;
    
    Bi_Image[80][97]=0;
    Bi_Image[81][97]=0;
    Bi_Image[82][97]=0;
    
    Bi_Image[71][95]=0;
    
    Bi_Image[74][89]=0;
    Bi_Image[75][89]=0;
    Bi_Image[76][89]=0;
    Bi_Image[77][89]=0;
    Bi_Image[78][89]=0;
    Bi_Image[79][89]=0;
    Bi_Image[80][89]=0;
    Bi_Image[81][89]=0;
    Bi_Image[82][89]=0;
    Bi_Image[83][89]=0;
    Bi_Image[84][89]=0;
    Bi_Image[85][89]=0;
    
    Bi_Image[74][101]=0;
    Bi_Image[75][101]=0;
    Bi_Image[76][101]=0;
    Bi_Image[77][101]=0;
    Bi_Image[78][101]=0;
    Bi_Image[79][101]=0;
    Bi_Image[80][101]=0;
    Bi_Image[81][101]=0;
    Bi_Image[82][101]=0;
    Bi_Image[83][101]=0;
    Bi_Image[84][101]=0;
    Bi_Image[85][101]=0;
    
    //Bi_Image[83][94]=0;
    Bi_Image[84][94]=0;
    //Bi_Image[83][96]=0;
    Bi_Image[84][96]=0;
   
    
     ///////////////////Write image/////////////////////
     ofstream bofile("Binary_shade_2.raw",ios_base::out | ios_base::binary);
     if (!bofile)
     {
     cout<<"open failed"<<endl;
     exit(1);
     }
     for (pO=0;pO<Size_H;pO++)
     for (qO=0;qO<Size_W;qO++)
     {
     
     if (Bi_Image[pO][qO]==1)
     kk=0;
     else
     kk=255;
     for (c=0;c<BytesPerPixel;c++)
     {
     Se_Image[pO][qO][c]=kk+0x00;    //Convert to hex or bin
     bofile.write((char*)&Se_Image[pO][qO][c],sizeof(Se_Image[pO][qO][c]));
     }
     }
     bofile.close();
    
    /////////Pre-processing of initial binary image/////////////
    int Size_In_H=0,Size_In_W=0;
    int Size_Out_H=0,Size_Out_W=0;
    
    int cord_2_H=0,cord_2_W=0;
    int cord_5_H=0,cord_5_W=0;
    
    unsigned short a,b;         //coefficients in bilinear interpolation
    unsigned short m,n;        //coefficients in bilinear interpolation (on edge)
    
    Size_In_H=59; Size_In_W=47;
    Size_Out_H=26; Size_Out_W=20;
    
    cord_2_H=95;cord_2_W=43;
    
    unsigned char large_2   [59][47][BytesPerPixel]={0};
    unsigned char small_2   [26][20][BytesPerPixel]={0};
    
    for (pI=0;pI<Size_In_H;++pI)
        for (qI=0;qI<Size_In_W;++qI)
        {
            for (c=0;c<BytesPerPixel;c++)
            {
                large_2[pI][qI][c]=Se_Image[pI+cord_2_H][qI+cord_2_W][c];
                Se_Image[pI+cord_2_H][qI+cord_2_W][c]=255;
            }
            //Label[pI+cord_1_H][qI+cord_1_W]=0;
        }
    /////////////////Resizing_2////////////////////////
    for (pO=0;pO<=Size_Out_H;++pO)
        for (qO=0;qO<Size_Out_W;++qO)
            for (c=0;c<BytesPerPixel;++c)
            {
                //Out_Image[pO][qO]=0;   //initialization
                
                //the four corners of the image
                if ( ((pO==0) || (pO==Size_Out_H-1)) && (qO==0 || (qO==Size_Out_W-1)))
                {
                    small_2[0]           [0]           [c]=large_2[0]          [0]          [c];
                    small_2[0]           [Size_Out_W-1][c]=large_2[0]          [Size_In_W-1][c];
                    small_2[Size_Out_H-1][0]           [c]=large_2[Size_In_H-1][0]          [c];
                    small_2[Size_Out_H-1][Size_Out_W-1][c]=large_2[Size_In_H-1][Size_In_W-1][c];
                }
                
                //the first and last rows
                else if (((pO==0) || (pO==Size_Out_H-1)) && ((qO!=0) && (qO!=Size_Out_W-1)))
                {
                    //mapping and find the start of the area in original image
                    if (pO==0)
                        pI=0;
                    else
                        pI=Size_In_H-1;
                    qI=qO*Size_In_W/Size_Out_W;
                    //if the mapping of one pixel is on a corner of input image
                    if (qI==Size_In_W-1)
                        small_2[pO][qO][c]=large_2[pI][Size_In_W-1][c];
                    else
                    {
                        m=(unsigned short)qO*Size_In_W/Size_Out_W-qI;
                        //calculate coefficients of Bilinear Interpolation
                        small_2[pO][qO][c]=(1-m)*large_2[pI][qI][c]+m*large_2[pI][qI+1][c];   //Bilinear Interpolation
                    }
                }
                
                //the first and last culumns
                else if (((pO!=0) && (pO!=Size_Out_H-1)) && ((qO==0) || (qO==Size_Out_W-1)))
                {
                    //mapping and find the start of the area in original image
                    if (qO==0)
                        qI=0;
                    else
                        qI=Size_In_W-1;
                    pI=pO*Size_In_H/Size_Out_H;
                    //if the mapping of one pixel is on a corner of input image
                    if (pI==Size_In_H-1)
                        small_2[pO][qO][c]=large_2[Size_In_H-1][qI][c];
                    else
                    {
                        n=(unsigned short)pO*Size_In_H/Size_Out_H-pI;
                        //calculate coefficients of Bilinear Interpolation
                        small_2[pO][qO][c]=(1-n)*large_2[pI][qI][c]+n*large_2[pI+1][qI][c];   //Bilinear Interpolation
                    }
                }
                
                else
                {
                    //mapping and find the start of the area in original image
                    pI=pO*Size_In_H/Size_Out_H;
                    qI=qO*Size_In_W/Size_Out_W;
                    //calculate coefficients of Bilinear Interpolation
                    a=(unsigned short)pO*Size_In_H/Size_Out_H-pI;
                    b=(unsigned short)qO*Size_In_W/Size_Out_W-qI;
                    //Bilinear Interpolation
                    small_2[pO][qO][c]=(1-a)*(1-b)*large_2[pI][qI][c]+(1-a)*b*large_2[pI][qI+1][c]+a*(1-b)*large_2[pI+1][qI][c]+a*b*large_2[pI+1][qI+1][c];
                    
                }
            }
    
    for (pO=0;pO<Size_Out_H;++pO)
        for (qO=0;qO<Size_Out_W;++qO)
        {
            for (c=0;c<BytesPerPixel;++c)
                Se_Image[pO+cord_2_H][qO+cord_2_W][c]=small_2[pO][qO][c];
            //if (small_1[pO][qO][2]==0)
            //Label[pO+cord_1_H][qO+cord_1_W]=11;
        }
    
    //////////////////////////////////////////////////////
    
    Size_In_H=59; Size_In_W=48;
    Size_Out_H=26; Size_Out_W=21;
    
    cord_5_H=93;cord_5_W=101;
    
    unsigned char large_5   [59][48][BytesPerPixel]={0};
    unsigned char small_5   [26][21][BytesPerPixel]={0};
    
    for (pI=0;pI<Size_In_H;++pI)
        for (qI=0;qI<Size_In_W;++qI)
        {
            for (c=0;c<BytesPerPixel;c++)
            {
                large_5[pI][qI][c]=Se_Image[pI+cord_5_H][qI+cord_5_W][c];
                Se_Image[pI+cord_5_H][qI+cord_5_W][c]=255;
            }
            //Label[pI+cord_5_H][qI+cord_5_W]=0;
        }
    
    /////////////////Resizing_5////////////////////////
    for (pO=0;pO<=Size_Out_H;++pO)
        for (qO=0;qO<Size_Out_W;++qO)
            for (c=0;c<BytesPerPixel;++c)
            {
                //Out_Image[pO][qO]=0;   //initialization
                
                //the four corners of the image
                if ( ((pO==0) || (pO==Size_Out_H-1)) && (qO==0 || (qO==Size_Out_W-1)))
                {
                    small_5[0]           [0]           [c]=large_5[0]          [0]          [c];
                    small_5[0]           [Size_Out_W-1][c]=large_5[0]          [Size_In_W-1][c];
                    small_5[Size_Out_H-1][0]           [c]=large_5[Size_In_H-1][0]          [c];
                    small_5[Size_Out_H-1][Size_Out_W-1][c]=large_5[Size_In_H-1][Size_In_W-1][c];
                }
                
                //the first and last rows
                else if (((pO==0) || (pO==Size_Out_H-1)) && ((qO!=0) && (qO!=Size_Out_W-1)))
                {
                    //mapping and find the start of the area in original image
                    if (pO==0)
                        pI=0;
                    else
                        pI=Size_In_H-1;
                    qI=qO*Size_In_W/Size_Out_W;
                    //if the mapping of one pixel is on a corner of input image
                    if (qI==Size_In_W-1)
                        small_5[pO][qO][c]=large_5[pI][Size_In_W-1][c];
                    else
                    {
                        m=(unsigned short)qO*Size_In_W/Size_Out_W-qI;
                        //calculate coefficients of Bilinear Interpolation
                        small_5[pO][qO][c]=(1-m)*large_5[pI][qI][c]+m*large_5[pI][qI+1][c];   //Bilinear Interpolation
                    }
                }
                
                //the first and last culumns
                else if (((pO!=0) && (pO!=Size_Out_H-1)) && ((qO==0) || (qO==Size_Out_W-1)))
                {
                    //mapping and find the start of the area in original image
                    if (qO==0)
                        qI=0;
                    else
                        qI=Size_In_W-1;
                    pI=pO*Size_In_H/Size_Out_H;
                    //if the mapping of one pixel is on a corner of input image
                    if (pI==Size_In_H-1)
                        small_5[pO][qO][c]=large_5[Size_In_H-1][qI][c];
                    else
                    {
                        n=(unsigned short)pO*Size_In_H/Size_Out_H-pI;
                        //calculate coefficients of Bilinear Interpolation
                        small_5[pO][qO][c]=(1-n)*large_5[pI][qI][c]+n*large_5[pI+1][qI][c];   //Bilinear Interpolation
                    }
                }
                
                else
                {
                    //mapping and find the start of the area in original image
                    pI=pO*Size_In_H/Size_Out_H;
                    qI=qO*Size_In_W/Size_Out_W;
                    //calculate coefficients of Bilinear Interpolation
                    a=(unsigned short)pO*Size_In_H/Size_Out_H-pI;
                    b=(unsigned short)qO*Size_In_W/Size_Out_W-qI;
                    //Bilinear Interpolation
                    small_5[pO][qO][c]=(1-a)*(1-b)*large_5[pI][qI][c]+(1-a)*b*large_5[pI][qI+1][c]+a*(1-b)*large_5[pI+1][qI][c]+a*b*large_5[pI+1][qI+1][c];
                    
                }
            }
    
    for (pO=0;pO<Size_Out_H;++pO)
        for (qO=0;qO<Size_Out_W;++qO)
        {
            for (c=0;c<BytesPerPixel;++c)
                Se_Image[pO+cord_5_H][qO+cord_5_W][c]=small_5[pO][qO][c];
            //if (small_5[pO][qO][1]==0)
            //Label[pO+cord_5_H][qO+cord_1_W]=12;
        }
    
    for (pO=0;pO<Size_H;++pO)
        for (qO=0;qO<Size_W;++qO)
        {
            if (Se_Image[pO][qO][0]==0)
                Bi_Image[pO][qO]=1;
            else
                Bi_Image[pO][qO]=0;
        }
    
    
    //remove the frame
    for (pI=0;pI<Size_H;pI++)
    {
        
        for (qI=0;qI<Size_W;qI++)
        {
            if (pI>25 && pI<125)
            {
                if (qI>40 && qI<153)
                    Bi_Image[pI][qI]=Bi_Image[pI][qI];
                else
                    Bi_Image[pI][qI]=0;
            }
            else
                Bi_Image[pI][qI]=0;
        }
    }
    
     ///////////////////Write image/////////////////////
     ofstream cofile("Binary_shade_3.raw",ios_base::out | ios_base::binary);
     if (!cofile)
     {
     cout<<"open failed"<<endl;
     exit(1);
     }
     for (pO=0;pO<Size_H;pO++)
     for (qO=0;qO<Size_W;qO++)
     {
     
     if (Bi_Image[pO][qO]==1)
     kk=0;
     else
     kk=255;
     for (c=0;c<BytesPerPixel;c++)
     {
     Se_Image[pO][qO][c]=kk+0x00;    //Convert to hex or bin
     cofile.write((char*)&Se_Image[pO][qO][c],sizeof(Se_Image[pO][qO][c]));
     }
     }
     cofile.close();
    
    
    ///////////////Object Segmentation////////////////
    int neigh_value=0;     //checking the labels of neighbors
    int label=1;
    int min=0,temp=0;
    int link[30][30]={0};  //the label table
    int link_min[30]={0};  //the minimum label each label connects
    //int j=0;
    
    for (pI=1;pI<Size_H-1;pI++)
        for (qI=1;qI<Size_W-1;qI++)
        {
            //non-background
            if (Bi_Image[pI][qI]==1)
            {
                neigh_value=Bi_Image[pI][qI-1]+Bi_Image[pI-1][qI-1]+Bi_Image[pI-1][qI]+Bi_Image[pI-1][qI+1];
                //surround by background
                if (neigh_value==0)
                {
                    Label[pI][qI]=label;
                    label++;
                }
                else
                {
                    //find the minimum label surrounded
                    if (Label[pI][qI-1]!=0)
                        min=Label[pI][qI-1];
                    if (Label[pI-1][qI-1]!=0)
                        min=Label[pI-1][qI-1];
                    if (Label[pI-1][qI]!=0)
                        min=Label[pI-1][qI];
                    if (Label[pI-1][qI+1]!=0)
                        min=Label[pI-1][qI+1];
                    
                    if  (Label[pI][qI-1]!=0)
                    {
                        temp=Label[pI][qI-1];
                        if (temp<min)
                            min=temp;
                    }
                    if  (Label[pI-1][qI-1]!=0)
                    {
                        temp=Label[pI-1][qI-1];
                        if (temp<min)
                            min=temp;
                    }
                    if  (Label[pI-1][qI]!=0)
                    {
                        temp=Label[pI-1][qI];
                        if (temp<min)
                            min=temp;
                    }
                    if  (Label[pI-1][qI+1]!=0)
                    {
                        temp=Label[pI-1][qI+1];
                        if (temp<min)
                            min=temp;
                    }
                    //minimum
                    Label[pI][qI]=min;
                    
                    //update the label tabel
                    if  (Label[pI][qI-1]!=0)
                    {
                        temp=Label[pI][qI-1];
                        link[min][temp]=1;
                        link[temp][min]=1;
                        
                    }
                    if  (Label[pI-1][qI-1]!=0)
                    {
                        temp=Label[pI-1][qI-1];
                        link[min][temp]=1;
                        link[temp][min]=1;
                    }
                    if  (Label[pI-1][qI]!=0)
                    {
                        temp=Label[pI-1][qI];
                        link[min][temp]=1;
                        link[temp][min]=1;
                    }
                    if  (Label[pI-1][qI+1]!=0)
                    {
                        temp=Label[pI-1][qI+1];
                        link[min][temp]=1;
                        link[temp][min]=1;
                    }
                    
                    
                }
            }
            
        }
    //cout<<label<<endl;

    //int j=0,k=0;
    //complete the label table
    for (pI=0;pI<30;pI++)
        for (qI=0;qI<30;qI++)
        {
            if (link[pI][qI]!=0)
            {
                for (j=0;j<30;j++)
                {
                    if (link[qI][j]!=0)
                    {
                        link[j][pI]=1;
                        link[pI][j]=1;
                    }
                }
                
            }
        }
    /*
     for (pI=0;pI<30;pI++)
     {
     cout<<endl;
     for (qI=0;qI<30;qI++)
     {
     cout<<link[pI][qI]<<" ";
     
     }
     }
     */
    
    //find the minimum label each label connects
    for (pI=0;pI<30;pI++)
        for (qI=0;qI<30;)
        {
            if (link[pI][qI]!=0)
            {
                link_min[pI]=qI;
                //if (qI!=1)
                //obj++;
                qI=30;
            }
            else
                qI++;
        }
    
    //for (pI=0;pI<30;pI++)
        //cout<<link_min[pI]<<endl;
    
    //label the object by different colors
    for (pO=0;pO<Size_H;pO++)
        for (qO=0;qO<Size_W;qO++)
        {
            if (link_min[Label[pO][qO]]==7)
            {
                Se_Image[pO][qO][0]=0;
                Se_Image[pO][qO][1]=0;
                Se_Image[pO][qO][2]=0;
                Label[pO][qO]=1; //S
            }
            
            else if (link_min[Label[pO][qO]]==5)
            {
                Se_Image[pO][qO][0]=127;
                Se_Image[pO][qO][1]=0;
                Se_Image[pO][qO][2]=0;
                Label[pO][qO]=2; //P
            }
            
            else if (link_min[Label[pO][qO]]==3)
            {
                Se_Image[pO][qO][0]=0;
                Se_Image[pO][qO][1]=127;
                Se_Image[pO][qO][2]=0;
                Label[pO][qO]=3; //E1
            }
            
            else if (link_min[Label[pO][qO]]==2)
            {
                Se_Image[pO][qO][0]=0;
                Se_Image[pO][qO][1]=0;
                Se_Image[pO][qO][2]=127;
                Label[pO][qO]=4; //E2
            }
            
            else if (link_min[Label[pO][qO]]==1)
            {
                Se_Image[pO][qO][0]=255;
                Se_Image[pO][qO][1]=0;
                Se_Image[pO][qO][2]=0;
                Label[pO][qO]=5; //D
            }
            
            else if (link_min[Label[pO][qO]]==19)
            {
                Se_Image[pO][qO][0]=0;
                Se_Image[pO][qO][1]=255;
                Se_Image[pO][qO][2]=0;
                Label[pO][qO]=6; //L
            }
            
            else if (link_min[Label[pO][qO]]==18)
            {
                Se_Image[pO][qO][0]=0;
                Se_Image[pO][qO][1]=0;
                Se_Image[pO][qO][2]=255;
                Label[pO][qO]=7; //I1
            }
            
            else if (link_min[Label[pO][qO]]==13)
            {
                Se_Image[pO][qO][0]=127;
                Se_Image[pO][qO][1]=127;
                Se_Image[pO][qO][2]=0;
                Label[pO][qO]=8; //M
            }
            
            else if (link_min[Label[pO][qO]]==14)
            {
                Se_Image[pO][qO][0]=127;
                Se_Image[pO][qO][1]=0;
                Se_Image[pO][qO][2]=127;
                Label[pO][qO]=9; //I2
            }
            
            else if (link_min[Label[pO][qO]]==12)
            {
                Se_Image[pO][qO][0]=0;
                Se_Image[pO][qO][1]=127;
                Se_Image[pO][qO][2]=127;
                Label[pO][qO]=10; //T
            }
            
            else if (link_min[Label[pO][qO]]==22)
            {
                Se_Image[pO][qO][0]=255;
                Se_Image[pO][qO][1]=255;
                Se_Image[pO][qO][2]=0;
                Label[pO][qO]=11; //2
            }
            
            else if (link_min[Label[pO][qO]]==21)
            {
                Se_Image[pO][qO][0]=255;
                Se_Image[pO][qO][1]=0;
                Se_Image[pO][qO][2]=255;
                Label[pO][qO]=12; //5
            }
            
            else
            {
                Se_Image[pO][qO][0]=255;
                Se_Image[pO][qO][1]=255;
                Se_Image[pO][qO][2]=255;
                Label[pO][qO]=0;
            }
        }
    
    
     ///////////////////Write image/////////////////////
     ofstream ofile("Segment_shade.raw",ios_base::out | ios_base::binary);
     if (!ofile)
     {
     cout<<"open failed"<<endl;
     exit(1);
     }
     for (pO=0;pO<Size_H;pO++)
     for (qO=0;qO<Size_W;qO++)
     {
     for (c=0;c<BytesPerPixel;c++)
     {
     Se_Image[pO][qO][c]=Se_Image[pO][qO][c]+0x00;    //Convert to hex or bin
     ofile.write((char*)&Se_Image[pO][qO][c],sizeof(Se_Image[pO][qO][c]));
     }
     }
     ofile.close();
    
    ///////////////Segmentation///////////////
    int cord_size[13][4]={0};
    cord_size[ 1][0]=31; cord_size[ 1][1]=42; cord_size[ 1][2]=26; cord_size[ 1][3]=20; //S
    cord_size[ 2][0]=30; cord_size[ 2][1]=64; cord_size[ 2][2]=26; cord_size[ 2][3]=21; //P
    cord_size[ 3][0]=29; cord_size[ 3][1]=88; cord_size[ 3][2]=26; cord_size[ 3][3]=19; //E1
    cord_size[ 4][0]=28; cord_size[ 4][1]=108;cord_size[ 4][2]=26; cord_size[ 4][3]=20; //E2
    cord_size[ 5][0]=27; cord_size[ 5][1]=129;cord_size[ 5][2]=26; cord_size[ 5][3]=21; //D
    
    cord_size[ 6][0]=64; cord_size[ 6][1]=54; cord_size[ 6][2]=26; cord_size[ 6][3]=19; //L
    cord_size[ 7][0]=63; cord_size[ 7][1]=74; cord_size[ 7][2]=26; cord_size[ 7][3]=7;  //I1
    cord_size[ 8][0]=61; cord_size[ 8][1]=84; cord_size[ 8][2]=26; cord_size[ 8][3]=23; //M
    cord_size[ 9][0]=61; cord_size[ 9][1]=109;cord_size[ 9][2]=26; cord_size[ 9][3]=8;  //I2
    cord_size[10][0]=60; cord_size[10][1]=118;cord_size[10][2]=26; cord_size[10][3]=19; //T
    
    cord_size[11][0]=95; cord_size[11][1]=43; cord_size[11][2]=26; cord_size[11][3]=20; //2
    cord_size[12][0]=93; cord_size[12][1]=101;cord_size[12][2]=26; cord_size[12][3]=21; //5
    
    
    ///////////////Feature Extraction///////////////
    
    //bit quads
    int bit_quads_1=0;
    int bit_quads_2=0;
    int bit_quads_3=0;
    int bit_quads_4=0;
    int bit_quads_d=0;
    int bit_value=0;
    
    //int bit_value_matrix[2][2]={0};
    
    int Eulr[13]={0};     //Euler number
    int Area[13]={0};   //Area
    int Peri=0;   //Perimeter
    double Circ[13]={0};//Circularity
    double Symm_y[13][3]={0};//Symmetry: left & right
    double Symm_x[13][3]={0};//Symmetry: up & down
    int symm_axis_y=0; //Symmetry axis
    int symm_axis_x=0; //Symmetry axis
    
    //data of features of each object, including Euler number
    // int feature[19][3]={0};
    
    int lb=0;   //label
    
    //Hu's Moments
    //int k=0;j=0;
    //int m=0,n=0;
    double xj=0,yk=0;
    double x_j=0,y_k=0;
    //double xx=0,yy=0;
    double M[4][4]={0};
    double U[4][4]={0};
    double V[4][4]={0};
    double alpha=0;
    
    double Mnt_1[13]={0};//Moment 1
    double Mnt_2[13]={0};//Moment 2
    double Mnt_3[13]={0};//Moment 3
    double Mnt_4[13]={0};//Moment 4
    
    double horizon_max=0;
    double horizon_min=0;
    double horizon_value=0;
    int max_row[13]={0};
    int min_row[13]={0};
    
    for (lb=1;lb<13;lb++)
    {
        symm_axis_y=(int)cord_size[lb][3]/2;
        symm_axis_x=(int)cord_size[lb][2]/2;
        
        horizon_max=0;
        horizon_min=100;
        
        for (pI=cord_size[lb][0];pI<(cord_size[lb][0]+cord_size[lb][2]-1);pI++)
        {
            horizon_value=0;
            
            for (qI=cord_size[lb][1];qI<(cord_size[lb][1]+cord_size[lb][3]-1);qI++)
            {
                horizon_value+=Bi_Image[pI][qI];
                
                //compute the bits in 2X2 area
                bit_value=Bi_Image[pI][qI]+Bi_Image[pI][qI+1]+Bi_Image[pI+1][qI]+Bi_Image[pI+1][qI+1];
                
                if (bit_value==1)
                    bit_quads_1++;
                if (bit_value==3)
                    bit_quads_3++;
                if (bit_value==4)
                    bit_quads_4++;
                if (bit_value==2)
                {
                    if (Bi_Image[pI][qI]==Bi_Image[pI+1][qI+1])
                        bit_quads_d++;
                    else
                        bit_quads_2++;
                }
                
                //compute the values for symmetry (left & right)
                if (qI<(cord_size[lb][1]+symm_axis_y))
                    Symm_y[lb][0]+=Bi_Image[pI][qI];
                else
                    Symm_y[lb][1]+=Bi_Image[pI][qI];
                
                //compute the values for symmetry (up & down)
                if (pI<(cord_size[lb][0]+symm_axis_x))
                    Symm_x[lb][0]+=Bi_Image[pI][qI];
                else
                    Symm_x[lb][1]+=Bi_Image[pI][qI];
                
                //Moment: M matrix
                yk=(double)(pI-cord_size[lb][0])+0.5;xj=(double)(qI-cord_size[lb][1])+0.5;
                m=0;n=0;
                M[m][n]+=pow(xj,m)*pow(yk,n)*Bi_Image[pI][qI]/(pow(cord_size[lb][3],m)*pow(cord_size[lb][2],n));
                m=1;n=0;
                M[m][n]+=pow(xj,m)*pow(yk,n)*Bi_Image[pI][qI]/(pow(cord_size[lb][3],m)*pow(cord_size[lb][2],n));
                m=0;n=1;
                M[m][n]+=pow(xj,m)*pow(yk,n)*Bi_Image[pI][qI]/(pow(cord_size[lb][3],m)*pow(cord_size[lb][2],n));
                
            }
            if (horizon_value!=0 && horizon_value>horizon_max)
            {
                horizon_max=horizon_value;
                max_row[lb]=pI-cord_size[lb][0];
            }
            
            if (horizon_value!=0 && horizon_value<horizon_min)
            {
                horizon_min=horizon_value;
                min_row[lb]=pI-cord_size[lb][0];
            }
        }
        if (lb==1)
            cout<<"S"<<endl;
        if (lb==2)
            cout<<"P"<<endl;
        if (lb==3)
            cout<<"E1"<<endl;
        if (lb==4)
            cout<<"E2"<<endl;
        if (lb==5)
            cout<<"D"<<endl;
        if (lb==6)
            cout<<"L"<<endl;
        if (lb==7)
            cout<<"I1"<<endl;
        if (lb==8)
            cout<<"M"<<endl;
        if (lb==9)
            cout<<"I2"<<endl;
        if (lb==10)
            cout<<"T"<<endl;
        if (lb==11)
            cout<<"2"<<endl;
        if (lb==12)
            cout<<"5"<<endl;
        
        //compute the Euler number
        Eulr[lb]=(bit_quads_1-bit_quads_3+2*bit_quads_d)/4;
        
        //compute the Circularity
        Area[lb]=(bit_quads_1+2*bit_quads_2+3*bit_quads_3+4*bit_quads_4+2*bit_quads_d)/4;
        Peri=bit_quads_1+bit_quads_2+bit_quads_3+2*bit_quads_d;
        Circ[lb]=4*3.1415926*(double)Area[lb]/(double)(Peri*Peri);
        
        cout<<"E: "<<Eulr[lb]<<endl;
        //cout<<"A: "<<Area<<endl;
        //cout<<"P: "<<Peri<<endl;
        //cout<<"C: "<<Circ<<endl;
        
        bit_quads_1=0;
        bit_quads_2=0;
        bit_quads_3=0;
        bit_quads_4=0;
        bit_quads_d=0;
        bit_value=0;
        
        x_j=M[1][0]/M[0][0];
        y_k=M[0][1]/M[0][0];
        
        for (j=cord_size[lb][0];j<=(cord_size[lb][0]+cord_size[lb][2]-1);j++)
            for (k=cord_size[lb][1];k<=(cord_size[lb][1]+cord_size[lb][3]-1);k++)
            {
                yk=(double)(j-cord_size[lb][0])+0.5;xj=(double)(k-cord_size[lb][1])+0.5;
                
                m=2;n=0;
                U[m][n]+=pow((xj-x_j),m)*pow((yk-y_k),n)*Bi_Image[j][k];
                m=0;n=2;
                U[m][n]+=pow((xj-x_j),m)*pow((yk-y_k),n)*Bi_Image[j][k];
                m=1;n=1;
                U[m][n]+=pow((xj-x_j),m)*pow((yk-y_k),n)*Bi_Image[j][k];
                m=3;n=0;
                U[m][n]+=pow((xj-x_j),m)*pow((yk-y_k),n)*Bi_Image[j][k];
                m=0;n=3;
                U[m][n]+=pow((xj-x_j),m)*pow((yk-y_k),n)*Bi_Image[j][k];
                m=2;n=1;
                U[m][n]+=pow((xj-x_j),m)*pow((yk-y_k),n)*Bi_Image[j][k];
                m=1;n=2;
                U[m][n]+=pow((xj-x_j),m)*pow((yk-y_k),n)*Bi_Image[j][k];
                
            }
        
        m=2;n=0;alpha=(double)(m+n)/2+1;
        V[m][n]=U[m][n]/pow(M[0][0],alpha);
        m=0;n=2;alpha=(double)(m+n)/2+1;
        V[m][n]=U[m][n]/pow(M[0][0],alpha);
        m=1;n=1;alpha=(double)(m+n)/2+1;
        V[m][n]=U[m][n]/pow(M[0][0],alpha);
        m=3;n=0;alpha=(double)(m+n)/2+1;
        V[m][n]=U[m][n]/pow(M[0][0],alpha);
        m=0;n=3;alpha=(double)(m+n)/2+1;
        V[m][n]=U[m][n]/pow(M[0][0],alpha);
        m=2;n=1;alpha=(double)(m+n)/2+1;
        V[m][n]=U[m][n]/pow(M[0][0],alpha);
        m=1;n=2;alpha=(double)(m+n)/2+1;
        V[m][n]=U[m][n]/pow(M[0][0],alpha);
        
        Mnt_1[lb]=V[2][0]+V[0][2];
        Mnt_2[lb]=(V[2][0]-V[0][2])*(V[2][0]-V[0][2])+4*V[1][1]*V[1][1];
        Mnt_3[lb]=(V[3][0]-3*V[1][2])*(V[3][0]-3*V[1][2])+(V[0][3]-3*V[2][1])*(V[0][3]-3*V[2][1]);
        Mnt_4[lb]=(V[3][0]+V[1][2])*(V[3][0]+V[1][2])+(V[0][3]-V[2][1])*(V[0][3]-V[2][1]);
        //cout<<"M1: "<<Mnt_1[lb]<<endl;
        //cout<<"M2: "<<Mnt_2[lb]<<endl;
        //cout<<"M3: "<<Mnt_3[lb]<<endl;
        
        
        
        for (j=0;j<4;j++)
            for (k=0;k<4;k++)
            {
                M[j][k]=0;
                U[j][k]=0;
                V[j][k]=0;
            }
        cout<<endl;
    }

    double amax=Area[1],amin=Area[2];
    double cmax=Circ[1],cmin=Circ[2];
    
    double m1_max=Mnt_1[1],m1_min=Mnt_1[2];
    double m2_max=Mnt_2[1],m2_min=Mnt_2[2];
    double m3_max=Mnt_3[1],m3_min=Mnt_3[2];
    double m4_max=Mnt_4[1],m4_min=Mnt_4[2];
    
    double as_rt_max=cord_size[ 1][3],as_rt_min=cord_size[ 2][3];
    
    double atemp=0,ctemp=0,m1_temp=0,m2_temp=0,m3_temp=0,m4_temp=0,as_rt_temp=0;
    
    for (lb=1;lb<13;lb++)
    {
        atemp=Area[lb];
        if (atemp>amax)
            amax=atemp;
        if (atemp<amin)
            amin=atemp;
        
        ctemp=Circ[lb];
        if (ctemp>cmax)
            cmax=ctemp;
        if (ctemp<cmin)
            cmin=ctemp;
        
        m1_temp=Mnt_1[lb];
        if (m1_temp>m1_max)
            m1_max=m1_temp;
        if (m1_temp<m1_min)
            m1_min=m1_temp;
        
        m2_temp=Mnt_2[lb];
        if (m2_temp>m2_max)
            m2_max=m2_temp;
        if (m2_temp<m2_min)
            m2_min=m2_temp;
        
        m3_temp=Mnt_3[lb];
        if (m3_temp>m3_max)
            m3_max=m3_temp;
        if (m3_temp<m3_min)
            m3_min=m3_temp;
        
        m4_temp=Mnt_4[lb];
        if (m4_temp>m4_max)
            m4_max=m4_temp;
        if (m4_temp<m4_min)
            m4_min=m4_temp;
        
        as_rt_temp=cord_size[lb][3];
        if (as_rt_temp>as_rt_max)
            as_rt_max=as_rt_temp;
        if (as_rt_temp<as_rt_min)
            as_rt_min=as_rt_temp;
    }
    
    cout<<"Circularity"<<endl;
    for (lb=1;lb<13;lb++)
    {
        Circ[lb]=(Circ[lb]-cmin)/(cmax-cmin);
        cout<<Circ[lb]<<endl;
    }
    cout<<endl;
    
    double AsRt[13]={0};
    cout<<"Aspect Ratio"<<endl;
    for (lb=1;lb<13;lb++)
    {
        AsRt[lb]=(cord_size[lb][3]-as_rt_min)/(as_rt_max-as_rt_min);
        cout<<AsRt[lb]<<endl;
    }
    cout<<endl;
    
    cout<<"Symmetry1 (LR)"<<endl;
    for (lb=1;lb<13;lb++)
    {
        if (Symm_y[lb][0]<Symm_y[lb][1])
            Symm_y[lb][2]=Symm_y[lb][0]/Symm_y[lb][1];
        else
            Symm_y[lb][2]=Symm_y[lb][1]/Symm_y[lb][0];
        cout<<Symm_y[lb][2]<<endl;
    }
    cout<<endl;
    
    cout<<"Symmetry2 (UD)"<<endl;
    for (lb=1;lb<13;lb++)
    {
        if (Symm_x[lb][0]<Symm_x[lb][1])
            Symm_x[lb][2]=Symm_x[lb][0]/Symm_x[lb][1];
        else
            Symm_x[lb][2]=Symm_x[lb][1]/Symm_x[lb][0];
        cout<<Symm_x[lb][2]<<endl;
    }
    cout<<endl;
    
    cout<<"Moment 1"<<endl;
    for (lb=1;lb<13;lb++)
    {
        Mnt_1[lb]=(Mnt_1[lb]-m1_min)/(m1_max-m1_min);
        cout<<Mnt_1[lb]<<endl;
    }
    cout<<endl;
    
    cout<<"Moment 2"<<endl;
    for (lb=1;lb<13;lb++)
    {
        Mnt_2[lb]=(Mnt_2[lb]-m2_min)/(m2_max-m2_min);
        cout<<Mnt_2[lb]<<endl;
    }
    cout<<endl;
    
    cout<<"Moment 3"<<endl;
    for (lb=1;lb<13;lb++)
    {
        Mnt_3[lb]=(Mnt_3[lb]-m3_min)/(m3_max-m3_min);
        cout<<Mnt_3[lb]<<endl;
    }
    cout<<endl;
    
    cout<<"Moment 4"<<endl;
    for (lb=1;lb<13;lb++)
    {
        Mnt_4[lb]=(Mnt_4[lb]-m4_min)/(m4_max-m4_min);
        cout<<Mnt_4[lb]<<endl;
    }
    
    cout<<"max row"<<endl;
    for (lb=1;lb<13;lb++)
    {
        if (max_row[lb]>(cord_size[lb][2]/2))
            cout<<"down"<<endl;
        else
            cout<<"up"<<endl;
    }
    cout<<endl;
    
    cout<<"min row"<<endl;
    for (lb=1;lb<13;lb++)
    {
        if (min_row[lb]>(cord_size[lb][2]/2))
            cout<<"down"<<endl;
        else
            cout<<"up"<<endl;
    }
    cout<<endl;

    //////////////Decision Tree/////////////////
    for (lb=1;lb<13;lb++)
    {
        if (Eulr[lb]==1)
        {
            if (Circ[lb]<0.4)
            {
                if (Symm_x[lb][2]<0.7)
                    cout<<"No."<<lb<<" character is 7"<<endl;
                else
                {
                    if (Symm_y[lb][2]<0.75)
                    {
                        if (Mnt_1[lb]<0.5)
                            cout<<"No."<<lb<<" character is E"<<endl;
                        else
                            cout<<"No."<<lb<<" character is 3"<<endl;
                    }
                    else
                    {
                        if (Mnt_1[lb]<0.5)
                        {
                            if (AsRt[lb]==1)
                                cout<<"No."<<lb<<" character is M"<<endl;
                            else
                                cout<<"No."<<lb<<" character is S"<<endl;
                        }
                        else
                        {
                            if (max_row[lb]<(cord_size[lb][2]/2))
                                cout<<"No."<<lb<<" character is 5"<<endl;
                            else
                                cout<<"No."<<lb<<" character is 2"<<endl;
                        }
                        
                    }
                    
                }
                
                
            }
            else
            {
                if (Symm_y[lb][2]<0.5)
                {
                    if (AsRt[lb]<0.5)
                        cout<<"No."<<lb<<" character is 1"<<endl;
                    else
                        cout<<"No."<<lb<<" character is L"<<endl;
                }
                else
                {
                    if (Mnt_1[lb]<0.7)
                        cout<<"No."<<lb<<" character is T"<<endl;
                    else
                        cout<<"No."<<lb<<" character is I"<<endl;
                }
                
            }
            
        }
        else if (Eulr[lb]==0)
        {
            if (Symm_x[lb][2]<0.65)
            {
                if (Mnt_1[lb]<0.5)
                    cout<<"No."<<lb<<" character is P"<<endl;
                else
                    cout<<"No."<<lb<<" character is 4"<<endl;
            }
            else
            {
                if (Symm_y[lb][2]>0.95)
                    cout<<"No."<<lb<<" character is 0"<<endl;
                else
                {
                    if (AsRt[lb]>0.75)
                        cout<<"No."<<lb<<" character is D"<<endl;
                    else
                    {
                        if (min_row[lb]<(cord_size[lb][2]/2))
                            cout<<"No."<<lb<<" character is 6"<<endl;
                        else
                            cout<<"No."<<lb<<" character is 9"<<endl;
                    }
                }
                
            }
            
        }
        else
            cout<<"No."<<lb<<" character is 8"<<endl;
    }
    
    cout<<"The end!"<<endl;
    return 0;
}
